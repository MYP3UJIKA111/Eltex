#!/bin/bash
# template_task.sh — «бригадир»: работает только под чужим именем
NAME="$(basename "$0")"
if [ "$NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

RUN=/tmp/run
FIFO=$RUN/cuckoo.pid
LOG="report_${NAME}.log"

echo "$(date '+%F %T') [$$] Скрипт запущен" >> "$LOG"

N=5
if [ -p "$FIFO" ]; then
    echo "${NAME}[$$]: how much time do I have?" > "$FIFO"
    for _ in $(seq 1 50); do
        [ -f "$RUN/reply.$$" ] && { N=$(cat "$RUN/reply.$$"); rm -f "$RUN/reply.$$"; break; }
        sleep 0.2
    done
fi

sleep "$N"
echo "$(date '+%F %T') [$$] Скрипт завершился, работал $N секунд." >> "$LOG"
