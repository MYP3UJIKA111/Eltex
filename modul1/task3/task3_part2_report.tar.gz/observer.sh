#!/bin/bash
# observer.sh — перезапускает задачи из observer.conf, если их нет в /proc
DIR="$(cd "$(dirname "$0")" && pwd)"
CONF="$DIR/observer.conf"
LOG="$DIR/observer.log"
cd "$DIR" || exit 1
[ -r "$CONF" ] || exit 1

while read -r task; do
    case "$task" in ''|\#*) continue ;; esac
    name="$(basename "$task")"
    found=0
    for c in /proc/[0-9]*/cmdline; do
        [ -r "$c" ] || continue
        if tr '\0' '\n' 2>/dev/null < "$c" | grep -q "/$name$"; then
            found=1; break
        fi
    done
    if [ "$found" -eq 0 ]; then
        echo "$(date '+%F %T') Перезапуск: $name (не найден в /proc)" >> "$LOG"
        nohup "$DIR/$name" >/dev/null 2>&1 &
    fi
done < "$CONF"
