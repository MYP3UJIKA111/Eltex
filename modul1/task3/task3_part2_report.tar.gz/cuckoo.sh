#!/bin/bash
# cuckoo.sh — сервер выдачи времени через именованный канал
DIR="$(cd "$(dirname "$0")" && pwd)"
RUN=/tmp/run
FIFO=$RUN/cuckoo.pid
LOG=$DIR/cuckoo.log

mkdir -p "$RUN"
[ -p "$FIFO" ] || mkfifo "$FIFO"
exec 3<>"$FIFO"

echo "$(date '+%F %T') Startup!" >> "$LOG"

shutdown() {
    echo "$(date '+%F %T') Shutdown!" >> "$LOG"
    exit 0
}
trap shutdown TERM INT

while read -r line <&3; do
    case "$line" in
        *"how much time do I have?"*)
            np="${line%%:*}"          # NAME[PID]
            pid="${np#*[}"; pid="${pid%]}"
            N=$(( RANDOM % 9 + 2 ))   # 2..10
            echo "$(date '+%F %T') $np $N" >> "$LOG"
            echo "$N" > "$RUN/reply.$pid"
            ;;
    esac
done
